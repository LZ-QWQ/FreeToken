import json,torch
from pathlib import Path
from freetoken.moe.benchbw import Workload,_build_gather_rig,_cpu_moe_bank_sources
from freetoken.kernel.aot_models import expert_bank_row_bytes
torch.manual_seed(20261112)
rows=[]
for h,i in [(2560,640),(2048,512)]:
 wl=Workload('layout-check',h,i,4,2,('fp8_block',))
 cache,nbytes=_build_gather_rig('fp8_block',wl,torch.device('cuda'))
 expected=expert_bank_row_bytes('fp8_block',h,i)
 cpu=_cpu_moe_bank_sources('fp8_block',h,i,4)
 assert {k:t[0].numel()//4*t[0].element_size() for k,t in cache.bank_sources.items()}==expected
 assert {k:t.numel()//4*t.element_size() for k,t in cpu.items()}==expected
 assert nbytes==4*sum(expected.values()) and cache._copy_fused_ok
 for j,(name,source) in enumerate(cache.bank_sources.items()):
  raw=source[0].view(torch.uint8).reshape(4,-1)
  for e in range(4):raw[e].fill_(17*(j+1)+3*e)
 cache.src_indices[:4].copy_(torch.tensor([2,0,3,1],device="cuda",dtype=cache.src_indices.dtype))
 ids=cache.src_indices[:4].cpu().long()
 cache.copy_missing();torch.cuda.synchronize()
 for name,source in cache.bank_sources.items():
  want=source[0].view(torch.uint8).reshape(4,-1).index_select(0,ids)
  actual=cache.bank_caches[name].view(torch.uint8).reshape(4,-1).cpu()
  assert torch.equal(actual,want),name
 rows.append(dict(H=h,I=i,experts=4,row_bytes=expected,permuted_copy_bitwise=True,fused_dispatch=True,padded_cpu_banks_match=True))
 del cache,cpu
out=dict(status='padded_bench_banks_and_copy_pass',cases=rows,torch=torch.__version__,hip=torch.version.hip,cuda=torch.version.cuda)
Path('/validation/results/layout.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
