import argparse
import csv
import hashlib
import json
from pathlib import Path
import statistics as stats

p = argparse.ArgumentParser()
p.add_argument('--data-root', required=True)
p.add_argument('--output', required=True)
a = p.parse_args()
out = Path(a.output); out.mkdir(parents=True, exist_ok=True)
roots = {key: Path(a.data_root)/'devices'/key/'results/e2e'
         for key in ['n4', 'n5', 'aw', 'ar', 'h100']}

def describe(values):
    quartiles = stats.quantiles(values, n=4, method='inclusive')
    return dict(n=len(values), median=stats.median(values), min=min(values), max=max(values),
                q1=quartiles[0], q3=quartiles[2], mean=stats.mean(values))

report = {'method': 'all formal requests; two AB/BA cycles, three fixed prompts each; no outlier removal',
          'primary': 'per-request Decode median; delta is ratio of arm medians minus one',
          'decode_formula': '(committed tokens - first-batch tokens)/(last-batch time - first-batch time)',
          'pooled_formula': 'sum of token numerators / sum of corresponding wall intervals',
          'devices': {}, 'evidence_sha256': {}}
flat = []
for key, root in roots.items():
    rows = []
    for cycle in [0, 1]:
        for arm in ['before', 'after']:
            file = root/('cycle'+str(cycle)+'-'+arm)/'records.json'
            raw = file.read_bytes()
            report['evidence_sha256'][str(file)] = hashlib.sha256(raw).hexdigest()
            all_rows = json.loads(raw)
            assert len(all_rows) == 4 and sum(bool(x['warmup']) for x in all_rows) == 1
            for record in all_rows:
                if record['warmup']:
                    continue
                x = record; arrivals = x['arrivals']
                assert x['input_tokens'] == 32768 and x['output_tokens'] == x['returned_output_tokens'] == len(x['raw_token_ids']) == 256
                assert x['terminal_eos_tokens'] == 0 and x['ignore_eos']
                assert sum(batch[1] for batch in arrivals) == 256
                numerator = 256-arrivals[0][1]
                seconds = arrivals[-1][0]-arrivals[0][0]
                decode, generate = numerator/seconds, 256/x['seconds']
                assert abs(decode-x['decode_tokens_per_second']) < 1e-8
                assert abs(generate-x['committed_e2e_tokens_per_second']) < 1e-8
                gaps = [v[0]-u[0] for u, v in zip(arrivals, arrivals[1:])]
                row = dict(device=key, cycle=cycle, arm=arm, prompt=x['prompt_id'],
                           input_sha256=x['input_sha256'], output_sha256=x['output_sha256'],
                           committed=256, decode_numerator=numerator, decode_seconds=seconds,
                           generate_seconds=x['seconds'], decode=decode, generate=generate,
                           ttft=x['ttft_seconds'], accept=x['accept_length'], verify_steps=x['verify_request_steps'],
                           max_batch_gap=max(gaps), gaps_above_1s=sum(g>1 for g in gaps),
                           time_in_gaps_above_1s=sum(g for g in gaps if g>1))
                rows.append(row); flat.append(row)
    summary = {}
    for arm in ['before', 'after']:
        selected = [r for r in rows if r['arm'] == arm]
        assert len(selected) == 6
        summary[arm] = {name:describe([r[name] for r in selected])
                        for name in ['decode', 'generate', 'ttft', 'accept', 'max_batch_gap']}
        summary[arm]['pooled_decode'] = sum(r['decode_numerator'] for r in selected)/sum(r['decode_seconds'] for r in selected)
        summary[arm]['pooled_generate'] = sum(r['committed'] for r in selected)/sum(r['generate_seconds'] for r in selected)
    pairs = []
    for cycle in [0, 1]:
        left = {r['prompt']:r for r in rows if r['arm']=='before' and r['cycle']==cycle}
        right = {r['prompt']:r for r in rows if r['arm']=='after' and r['cycle']==cycle}
        assert left.keys() == right.keys() and len(left) == 3
        for prompt in left:
            b, c = left[prompt], right[prompt]
            assert b['input_sha256'] == c['input_sha256']
            pairs.append(dict(cycle=cycle, prompt=prompt, decode_ratio=c['decode']/b['decode'],
                              generate_ratio=c['generate']/b['generate'], output_equal=b['output_sha256']==c['output_sha256']))
    delta = {name:100*(summary['after'][name]['median']/summary['before'][name]['median']-1)
             for name in ['decode', 'generate', 'ttft']}
    delta['pooled_decode'] = 100*(summary['after']['pooled_decode']/summary['before']['pooled_decode']-1)
    delta['pooled_generate'] = 100*(summary['after']['pooled_generate']/summary['before']['pooled_generate']-1)
    repeats = []
    for arm in ['before', 'after']:
        for prompt in sorted({r['prompt'] for r in rows}):
            xs = [r for r in rows if r['arm']==arm and r['prompt']==prompt]
            repeats.append(dict(arm=arm, prompt=prompt, same_output=len({r['output_sha256'] for r in xs})==1,
                                same_verify_count=len({r['verify_steps'] for r in xs})==1))
    report['devices'][key] = dict(summary=summary, median_change_percent=delta, pairs=pairs,
                                  repeatability=repeats, samples=rows)

(out/'summary.json').write_text(json.dumps(report, indent=2)+'\n')
with (out/'samples.csv').open('w', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
for key, data in report['devices'].items():
    b, c = data['summary']['before'], data['summary']['after']
    print(key, 'Decode', b['decode']['median'], '->', c['decode']['median'],
          'delta%', data['median_change_percent']['decode'],
          'range', [b['decode']['min'],b['decode']['max']], [c['decode']['min'],c['decode']['max']],
          'pooled', b['pooled_decode'], '->', c['pooled_decode'])
