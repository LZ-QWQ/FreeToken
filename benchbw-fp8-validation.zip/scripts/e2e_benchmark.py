"""Same-source off/MTP/DFlash measurement; diagnostics run separately."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import time


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str)+'\n')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--workloads', default='anchor-greedy,anchor-sampled,math-sampled')
    p.add_argument('--cycle',type=int,default=0)
    p.add_argument('--math-max-tokens',type=int,default=16384)
    p.add_argument('--question', default='What is 2 + 2?')
    p.add_argument('--no-thinking', action='store_true')
    p.add_argument('--no-graphs', action='store_true')
    p.add_argument('--algorithm', choices=['off','mtp','dflash'], required=True)
    p.add_argument('--phase', choices=['smoke','bench'], default='smoke')
    p.add_argument('--lengths', default='128,32768')
    p.add_argument('--output-tokens', type=int, default=256)
    p.add_argument('--strategy', choices=['offload','hybrid'], required=True)
    p.add_argument('--cache-slots', type=int, required=True)
    p.add_argument('--cpu-threads', type=int, default=8)
    p.add_argument('--max-fetch', type=int, default=1)
    p.add_argument('--output', required=True)
    p.add_argument('--smoke-only', action='store_true')
    p.add_argument('--steps', type=int, default=2)
    p.add_argument('--audit-logits', action='store_true')
    p.add_argument('--pilot', action='store_true')
    a = p.parse_args()
    if a.algorithm=='off': a.steps=0
    out = Path(a.output)
    out.mkdir(parents=True, exist_ok=True)
    import torch
    import triton
    import transformers
    from freetoken.core import SamplingParams
    from freetoken.engine.config import EngineConfig
    from freetoken.llm import LLM
    from freetoken.message import DetokenizeMsg, PromptAdmittedMsg
    from freetoken.mm.config import MultimodalConfig

    def cpu_snapshot():
        return {l.split()[0]:list(map(int,l.split()[1:]))
                for l in Path('/proc/stat').read_text().splitlines() if l.startswith('cpu')}

    affinity = sorted(os.sched_getaffinity(0))

    def idle(before, after):
        values = {}
        for key in ['cpu', *['cpu'+str(i) for i in affinity]]:
            diff = [b-a for a,b in zip(before[key],after[key])]
            values[key] = diff[3]/max(1,sum(diff[:8]))
        return dict(host_idle=values['cpu'], allocated_idle=sum(values['cpu'+str(i)] for i in affinity)/len(affinity))

    def admit():
        # The host controller checks shared-resource admission before each launch.
        return

    class MeasuredLLM(LLM):
        measuring = False

        def _prepare_batch(self, batch):
            if self.measuring and batch.is_prefill:
                event = torch.cuda.Event(enable_timing=True)
                event.record(self.engine.stream)
                self.prefill_starts.append(event)
                self.chunks.append(dict(tokens=sum(r.extend_len for r in batch.reqs),
                    cached=[r.cached_len for r in batch.reqs], host_enqueue=time.perf_counter()))
            return super()._prepare_batch(batch)

        def offline_send_result(self, reply):
            now = time.perf_counter()
            if self.measuring:
                for msg in reply:
                    if isinstance(msg, PromptAdmittedMsg):
                        self.admissions.append(dict(uid=msg.uid, prompt_tokens=msg.prompt_tokens,
                                                    cached_tokens=msg.cached_tokens))
                    elif isinstance(msg, DetokenizeMsg) and msg.next_tokens:
                        self.arrivals.append([now, list(msg.next_tokens)])
                        if msg.finished: self.finish_reasons.append(msg.finish_reason)
            return super().offline_send_result(reply)

        def _drain_verify(self, batch, output, reply, new_finished_reqs):
            offered = [int(x) + 1 for x in output.emitted_cpu[:len(batch.reqs)]]
            before = len(reply)
            n = super()._drain_verify(batch, output, reply, new_finished_reqs)
            if self.measuring:
                self.verify_steps += len(batch.reqs)
                self.verify_committed += n
                for i, msg in enumerate(reply[before:]):
                    tokens = list(msg.next_tokens)
                    assert tokens == output.next_tokens_cpu[i, :len(tokens)].tolist()
                    assert 1 <= len(tokens) <= offered[i] <= a.steps + 1
                    self.verify_histogram[str(offered[i])] += 1
                    self.truncated_tokens += offered[i] - len(tokens)
            return n

        def measured(self, prompt, sampling):
            admit()
            self.arrivals, self.admissions, self.chunks = [], [], []
            self.finish_reasons = []
            self.verify_steps = self.verify_committed = self.truncated_tokens = 0
            self.verify_histogram = {str(i): 0 for i in range(1, a.steps + 2)}
            if a.audit_logits:
                from logit_hooks import reset
                reset()
            self.prefill_starts, self.prefill_ends = [], []
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
            cpu_before = cpu_snapshot()
            start_unix = time.time()
            start = time.perf_counter()
            self.measuring = True
            response = self.generate([prompt], sampling)[0]
            self.measuring = False
            torch.cuda.synchronize()
            end = time.perf_counter()
            assert len(self.prefill_starts) == len(self.prefill_ends) > 0
            raw_ids = [token for _, tokens in self.arrivals for token in tokens]
            n = len(raw_ids)
            terminal_eos = int(bool(raw_ids) and raw_ids[-1] in self.eos_token_ids)
            returned_ids = response['token_ids']
            assert returned_ids == (raw_ids[:-1] if terminal_eos else raw_ids), 'returned tokens differ beyond terminal EOS'
            if sampling.ignore_eos:
                assert n == sampling.max_tokens, 'ignore_eos request must commit the full requested count'
            first, last = self.arrivals[0][0], self.arrivals[-1][0]
            prefill_s = self.prefill_starts[0].elapsed_time(self.prefill_ends[-1])/1000
            assert sum(x['tokens'] for x in self.chunks) == len(prompt)
            assert self.admissions and all(x['cached_tokens']==0 for x in self.admissions)
            if a.audit_logits:
                from logit_hooks import validate
                dump(out / ('audit-' + str(len(list(out.glob('audit-*.json')))) + '.json'), validate(raw_ids))
            return dict(verify_request_steps=self.verify_steps, verify_committed_tokens=self.verify_committed,
                verify_offered_histogram=self.verify_histogram, truncated_tokens=self.truncated_tokens,
                accept_length=self.verify_committed/self.verify_steps if self.verify_steps else None,
                start_unix=start_unix, end_unix=time.time(), seconds=end-start,
                input_tokens=len(prompt), output_tokens=n, returned_output_tokens=len(returned_ids), terminal_eos_tokens=terminal_eos,
                ttft_seconds=first-start, prefill_seconds=prefill_s,
                prefill_tokens_per_second=len(prompt)/prefill_s,
                decode_seconds=last-first,
                decode_tokens_per_second=(n-len(self.arrivals[0][1]))/(last-first) if last>first else None,
                e2e_tokens_per_second=len(returned_ids)/(end-start), committed_e2e_tokens_per_second=n/(end-start), admissions=self.admissions,
                chunks=[dict(**x, gpu_seconds=s.elapsed_time(e)/1000)
                        for x,s,e in zip(self.chunks,self.prefill_starts,self.prefill_ends)],
                arrivals=[[t-start,len(tokens)] for t,tokens in self.arrivals],
                raw_token_ids=raw_ids, output_sha256=hashlib.sha256(json.dumps(raw_ids).encode()).hexdigest(),
                text=response['text'], finish_reasons=self.finish_reasons, cpu_interval=idle(cpu_before,cpu_snapshot()),
                peak_allocated=torch.cuda.max_memory_allocated(), peak_reserved=torch.cuda.max_memory_reserved())

    with socket.socket() as s:
        s.bind(('127.0.0.1',0))
        addr = 'tcp://127.0.0.1:'+str(s.getsockname()[1])
    EngineConfig.distributed_addr = property(lambda self: addr)
    config = dict(model_path='/models/Qwen3.8-Flash-Next-FP8', dtype=torch.bfloat16,
        max_running_req=1, max_extend_tokens=8192, max_seq_len_override=40960,
        num_token_override=40960, kv_reserve_tokens=40960,
        moe_strategy=a.strategy, moe_cache_size=a.cache_slots, moe_cache_auto=False,
        moe_hybrid_max_fetch=a.max_fetch, moe_cpu_threads=a.cpu_threads,
        cuda_graph_max_bs=0 if a.no_graphs else 1, cache_type='naive', ple_backend='disk', memory_ratio=.85,
        mm=MultimodalConfig(disabled_encoders=frozenset(('vision','audio'))))
    if a.steps:
        config.update(speculative_algorithm=a.algorithm, speculative_num_steps=a.steps)
        if a.algorithm=='dflash': config['speculative_draft_model_path']='/draft'
    if a.audit_logits:
        from logit_hooks import install
        install()
    dump(out/'config.json',config)
    torch.manual_seed(844)
    llm = MeasuredLLM(**config)
    try:
        engine = llm.engine
        original_forward_logits = engine.forward_logits

        def timed_logits(batch):
            result = original_forward_logits(batch)
            if llm.measuring and batch.is_prefill:
                event = torch.cuda.Event(enable_timing=True)
                event.record(engine.stream)
                llm.prefill_ends.append(event)
            return result

        engine.forward_logits = timed_logits
        from freetoken.kernel.triton.e4m3_compat import e4m3_native, e4m3_act_dtype
        import ctypes
        deployment = json.loads(Path('/validation/environment/e2e-device.json').read_text())['config']
        runtime = ctypes.CDLL('libamdhip64.so' if torch.version.hip else '/usr/local/cuda/lib64/libcudart.so')
        bdf = ctypes.create_string_buffer(64)
        get_bus = runtime.hipDeviceGetPCIBusId if torch.version.hip else runtime.cudaDeviceGetPCIBusId
        assert get_bus(bdf,64,0)==0 and torch.cuda.device_count()==1
        assert bdf.value.decode().lower()==deployment['bdf']
        if torch.version.hip:assert os.environ['ROCR_VISIBLE_DEVICES']==deployment['gpu']
        else:assert os.environ['CUDA_VISIBLE_DEVICES']=='0'
        props=torch.cuda.get_device_properties(0)
        if not torch.version.hip:assert str(props.uuid).removeprefix('GPU-')==deployment['gpu'].removeprefix('GPU-')
        from freetoken.engine.sample import sampling_module
        dump(out/'runtime.json',dict(bdf=bdf.value.decode().lower(),torch=torch.__version__,cuda=torch.version.cuda,hip=torch.version.hip,triton=triton.__version__,
            transformers=transformers.__version__,gpu=str(props),gpu_uuid=str(getattr(props,'uuid',None)),capability=list(torch.cuda.get_device_capability(0)),
            cpu_affinity=affinity,native_e4m3=e4m3_native(),quantized_activation_buffer=str(e4m3_act_dtype()),sampling_module=sampling_module().__name__))
        cache = engine.moe_offload_cache
        executor = engine.cpu_moe_executor
        dump(out/'engine.json',dict(config=vars(engine.config),num_pages=engine.num_pages,
            kernel_io=getattr(executor,'_kernel_io',None),
            graph_io_safe=executor.graph_capture_safe(torch.bfloat16) if executor is not None else None,
            locked_hybrid=sorted(getattr(cache,'locked_hybrid',[])),
            locked_staging=getattr(cache,'locked_fetch',None) is not None,
            attention_backend=engine.config.attention_backend,attention_backend_class=type(engine.attn_backend).__module__+'.'+type(engine.attn_backend).__name__,cache_size=cache.cache_size,graph_bs=getattr(engine.graph_runner,'graph_bs_list',[]),
            cpu_executor=engine.cpu_moe_executor is not None,
            hybrid_max_fetch=getattr(cache,'hybrid_max_fetch',None),hybrid_fetch_fraction=getattr(cache,'hybrid_fetch_fraction',None),
            allocated=torch.cuda.memory_allocated(),reserved=torch.cuda.memory_reserved(),
            mem_info=torch.cuda.mem_get_info()))
        from freetoken.moe.bench_profile import fetch_fraction
        profile_path = os.environ['FREETOKEN_BENCHBW_PATH']
        profile = json.loads(Path(profile_path).read_text())
        fractions = [fetch_fraction(row) for row in profile['layer_kinds'].values()]
        assert len(fractions) == 1 and a.max_fetch == -1
        expected = fractions[0] or 0.0
        actual = cache.hybrid_fetch_fraction
        assert actual and all(abs(x - expected) < 1e-12 for x in actual), (expected, actual)
        assert cache.hybrid_max_fetch == 1
        dump(out/'profile-resolution.json', dict(profile_path=profile_path,
            profile_sha256=hashlib.sha256(Path(profile_path).read_bytes()).hexdigest(),
            expected_fraction=expected, layer_fractions=actual,
            mode='fixed_cap_1_fallback' if expected == 0 else 'profile_fraction',
            user_max_fetch=a.max_fetch))
        if executor is not None:
            assert executor.graph_capture_safe(torch.bfloat16), 'CPU MoE graph IO qualification failed'
        assert (engine.spec is not None) == (a.steps > 0)
        if a.steps: assert engine.spec.k == a.steps
        assert engine.config.moe_strategy == a.strategy
        assert cache.cache_size == a.cache_slots
        assert engine.num_pages*engine.config.page_size >= 40960
        assert (engine.cpu_moe_executor is not None) == (a.strategy=='hybrid')
        prompt = llm.tokenizer.apply_chat_template([dict(role='user',content=a.question)],
                    tokenize=True,add_generation_prompt=True,enable_thinking=not a.no_thinking,return_dict=False)
        smoke = llm.measured(prompt,SamplingParams(temperature=0,max_tokens=32,ignore_eos=True))
        assert smoke['output_tokens'] == 32
        dump(out/'smoke.json',smoke)
        print('SMOKE',json.dumps({k:v for k,v in smoke.items() if k not in ('text','raw_token_ids','arrivals')}),flush=True)
        if a.smoke_only or a.phase=='smoke':
            dump(out/'complete.json',dict(status='pass',algorithm=a.algorithm,steps=a.steps,use_for_performance=False))
            return
        pack=json.loads(Path('/validation/inputs/prompts.json').read_text())
        math = {}
        workloads=a.workloads.split(',')
        assert workloads == ['anchor-greedy']
        if a.audit_logits:assert workloads==['anchor-greedy']
        if a.pilot:assert len(workloads)==1
        records=[]
        import re,importlib.util
        for workload in workloads:
            sampled=workload!='anchor-greedy'
            cases=[]
            if workload.startswith('anchor'):
                for length in [int(n) for n in a.lengths.split(',')]:
                    selected=pack['prompts'][:1] if a.pilot else (pack['prompts'][1:2] if a.audit_logits else pack['prompts'])
                    for i,case in enumerate(selected):
                        ids=case['token_ids']
                        if length<len(ids):
                            suffix=min(64,length//2);ids=ids[:length-suffix]+ids[-suffix:]
                        assert len(ids)==length
                        cases.append(dict(ids=ids,id=case['id'],warmup=i==0 and not a.audit_logits and not a.pilot,max_tokens=a.output_tokens,ignore_eos=True,seed=844000+100*a.cycle+10*int(sampled)+i))
            else:
                ids=llm.tokenizer.apply_chat_template([dict(role='user',content=math['prompt'])],tokenize=True,add_generation_prompt=True,enable_thinking=True,return_dict=False)
                for i in range(4):cases.append(dict(ids=ids,id='aime25-problem1-seed'+str(i),warmup=i==0,max_tokens=a.math_max_tokens,ignore_eos=False,seed=857000+100*a.cycle+i))
            for i,case in enumerate(cases):
                torch.manual_seed(case['seed'])
                row=llm.measured(case['ids'],SamplingParams(temperature=1.0 if sampled else 0,top_p=.95,top_k=20,max_tokens=case['max_tokens'],ignore_eos=case['ignore_eos']))
                row.update(warmup=case['warmup'],repeat=i-1,prompt_id=case['id'],strategy=a.strategy,algorithm=a.algorithm,steps=a.steps,thinking=True,
                    workload=workload,temperature=1.0 if sampled else 0.0,top_p=.95,top_k=20,seed=case['seed'],cycle=a.cycle,
                    max_tokens=case['max_tokens'],ignore_eos=case['ignore_eos'],input_sha256=hashlib.sha256(json.dumps(case['ids']).encode()).hexdigest())
                assert row['output_tokens']==row['returned_output_tokens']+row['terminal_eos_tokens']
                if case['ignore_eos']:assert row['output_tokens']==a.output_tokens
                else:
                    boxed=re.findall(r'\\boxed\{([^{}]+)\}',row['text'])
                    answer=ref.extract_answer(row['text'])
                    row.update(expected_answer=math['answer'],extracted_answer=answer,boxed_answer=boxed[-1].strip() if boxed else None,answer_correct=answer is not None and answer.lstrip('0')==str(math['answer']),hit_token_limit=row['output_tokens']>=case['max_tokens'])
                records.append(row);dump(out/'records.json',records)
                print('MEASUREMENT',json.dumps({k:v for k,v in row.items() if k not in ('text','raw_token_ids','arrivals')}),flush=True)
        dump(out/'complete.json',dict(status='pass',algorithm=a.algorithm,steps=a.steps,workloads=workloads,formal_samples=sum(not x['warmup'] for x in records),use_for_performance=not a.audit_logits and not a.pilot))
    finally:
        llm.shutdown()


if __name__=='__main__': main()
